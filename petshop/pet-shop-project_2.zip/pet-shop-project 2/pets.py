def find_pet(id):
    pass


def get_pets():
    pass
