def get_cart():
    pass


def save_cart(data):
    pass


def get_cart_total(cart):
    pass
